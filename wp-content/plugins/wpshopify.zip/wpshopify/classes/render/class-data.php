<?php

namespace WPS\Render;

if (!defined('ABSPATH')) {
	exit;
}

class Data {

	public $Templates;

	public function __construct($Templates) {
		$this->Templates = $Templates;
	}


	/*



	*/
	public function test() {

    echo 'test';

	}


}
