<div id="wps-errors" class="wps-is-hidden"></div>
<div id="wps-admin-notices" class="wps-is-hidden"></div>
