<!--

Upgrade to Pro message

-->

<div class="" id="wps-plugin-info-pro">

  <h3><?php esc_html_e('Upgrade to WP Shopify Pro', WPS_PLUGIN_TEXT_DOMAIN); ?></h3>

  <p><?php _e('WP Shopify Pro comes packed with a ton of useful features like over 80+ templates, automatic syncing, order / customer data and more! <a href="https://wpshop.io/purchase" target="_blank">Take your store to the next level today.</a>', WPS_PLUGIN_TEXT_DOMAIN); ?></p>

</div>
