<?php

/*

@description   The closing tag for the pagination container

@version       1.0.0
@since         1.0.49
@path          templates/partials/pagination/end.php

@docs          https://wpshop.io/docs/templates/pagination/end

*/

if ( !defined('ABSPATH') ) {
	exit;
}

?>

</div>
