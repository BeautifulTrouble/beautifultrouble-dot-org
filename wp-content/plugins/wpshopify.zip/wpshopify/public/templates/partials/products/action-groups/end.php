<?php

/*

@description   Closing tag used to group the add to cart and variant selection

@version       1.0.0
@since         1.0.49
@path          templates/partials/products/action-group/action-groups-end.php

@docs          https://wpshop.io/docs/templates/products/action-groups/action-groups-end

*/

if ( !defined('ABSPATH') ) {
	exit;
}

?>

</div>
