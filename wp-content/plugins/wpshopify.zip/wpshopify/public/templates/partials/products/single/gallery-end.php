<?php

/*

@description   Closing tags for product image gallery

@version       1.0.0
@since         1.0.49
@path          templates/partials/products/single/gallery-end.php

@docs          https://wpshop.io/docs/templates/products/single/gallery-end

*/

if ( !defined('ABSPATH') ) {
	exit;
}

?>

  </div>
</aside>
