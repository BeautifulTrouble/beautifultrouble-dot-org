<?php

/*

@description   Closing tag for image gallery thumbnails wrapper on product single page

@version       1.0.0
@since         1.0.49
@path          templates/partials/products/single/thumbs-end.php

@docs          https://wpshop.io/docs/templates/products/single/thumbs-end

*/

if ( !defined('ABSPATH') ) {
	exit;
}

?>

</div>
