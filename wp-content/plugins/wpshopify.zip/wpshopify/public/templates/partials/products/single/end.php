<?php

/*

@description   Closing tag for single product

@version       1.0.0
@since         1.0.49
@path          templates/partials/products/single/end.php

@docs          https://wpshop.io/docs/templates/products/single/end

*/

if ( !defined('ABSPATH') ) {
	exit;
}

?>

</div>
