<?php

/*

@description   Product pricing wrapper end

@version       1.0.0
@since         1.2.9
@path          templates/partials/products/add-to-cart/price-wrapper-end.php

@docs          https://wpshop.io/docs/templates/partials/products/add-to-cart/price-wrapper-end

*/

if ( !defined('ABSPATH') ) {
	exit;
}

?>

</div>
