<?php

/*

@description   Product pricing wrapper start

@version       1.0.0
@since         1.2.9
@path          templates/partials/products/add-to-cart/price-wrapper-start.php

@docs          https://wpshop.io/docs/templates/partials/products/add-to-cart/price-wrapper-start

*/

if ( !defined('ABSPATH') ) {
	exit;
}

?>

<div class="wps-price-wrapper wps-product-pricing wps-row">
