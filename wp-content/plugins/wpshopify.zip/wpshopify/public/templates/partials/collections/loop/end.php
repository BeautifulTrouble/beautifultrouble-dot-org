<?php

/*

@description   Closing tag for the main collections loop

@version       1.0.0
@since         1.0.49
@path          templates/partials/collections/loop/loop-end.php

@docs          https://wpshop.io/docs/templates/collections/loop/loop-end

*/

if ( !defined('ABSPATH') ) {
	exit;
}

?>

</ul>
