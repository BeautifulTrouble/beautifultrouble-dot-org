<?php

/*

@description   Closing tag for each collection link within loop

@version       1.0.0
@since         1.0.49
@path          templates/partials/collections/loop/item-link-end.php

@docs          https://wpshop.io/docs/templates/collections/loop/item-link-end

*/

if ( !defined('ABSPATH') ) {
	exit;
}

?>

</a>
