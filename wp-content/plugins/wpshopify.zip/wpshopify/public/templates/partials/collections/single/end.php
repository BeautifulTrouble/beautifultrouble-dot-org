<?php

/*

@description   Closing tag for single collection

@version       1.0.0
@since         1.0.49
@path          templates/partials/collections/single/end.php

@docs          https://wpshop.io/docs/templates/collections/single/end

*/

if ( !defined('ABSPATH') ) {
	exit;
}

?>

</div>
