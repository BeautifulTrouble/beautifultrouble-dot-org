<?php

/*

@description   Closing tags for each collection within loop

@version       1.0.0
@since         1.0.49
@path          templates/partials/collections/loop/item-end.php

@docs          https://wpshop.io/docs/templates/collections/loop/item-end

*/

if ( !defined('ABSPATH') ) {
	exit;
}

?>

  </div>
</li>
